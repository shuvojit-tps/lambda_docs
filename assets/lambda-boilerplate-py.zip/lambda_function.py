import datetime
import json

import pymysql

import db
import queries


def date_serializer(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()
    if isinstance(o, datetime.date):
        return o.__str__()


sales_conn = aptive_conn = None


def handler(event, context):
    """
    This function does something
    """

    global sales_conn, aptive_conn

    sales_conn = db.connect(event['stageVariables']['db_sales'])
    aptive_conn = db.connect(event['stageVariables']['db'])

    data = json.loads(event['body'])

    # Validate Request
    if list(data) != ['input-set-validation-goes-here']:
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                "Access-Control-Allow-Credentials": True
            },
            'body': json.dumps({
                'message': "Invalid request."
            })
        }

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            "Access-Control-Allow-Credentials": True
        },
        'body': json.dumps({}, default=date_serializer),
    }
