import pymysql
import boto3
import json
import logging
import sys


def connect(ssm_key):
    client = boto3.client('ssm')
    config_str = client.get_parameter(Name=ssm_key)['Parameter']['Value']
    config = json.loads(config_str)
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    try:
        conn = pymysql.connect(**config, connect_timeout=5)
    except pymysql.err.OperationalError:
        logger.error(
            "ERROR: Unexpected error: Could not connect to MySql instance.")
        sys.exit()
    return conn
